<?php

namespace SNT\ReservationBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * typeBien.
 *
 * @ORM\Table(name="type_bien")
 * @ORM\Entity(repositoryClass="SNT\ReservationBundle\Repository\typeBienRepository")
 */
class typeBien
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nomBien", type="string", length=50, unique=true)
     */
    private $nomBien;

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nomBien.
     *
     * @param string $nomBien
     *
     * @return typeBien
     */
    public function setNomBien($nomBien)
    {
        $this->nomBien = $nomBien;

        return $this;
    }

    /**
     * Get nomBien.
     *
     * @return string
     */
    public function getNomBien()
    {
        return $this->nomBien;
    }
}
